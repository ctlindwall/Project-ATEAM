# Project-ATEAM

Team Members:
Colin Lindwall - clindwall@wisc.edu - xTeam 130
Turner Valle - trvalle@wisc.edu - xTeam 67
Irene Stringer - istringer@wisc.edu xTeam 39
Chris Liou - czliou@wisc.edu - xTeam 67
